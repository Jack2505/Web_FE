# Web_BE_25dh230009 — Complete ASP.NET MVC5 Store Admin Project
## Included
- Visual Studio solution and classic .NET Framework MVC project
- Entity Framework 6 Code First models and LocalDB connection string
- Seeded sample categories/products
- Admin login/logout (demo credentials below)
- Admin layout
- Category CRUD
- Product CRUD
- Product image URL/path field (images can be placed in `Content/images`)
- Search by product name, description, or category
- Minimum/maximum price filters
- Sort by name or price, ascending/descending
- Paged results that preserve search/filter/sort settings

## Requirements
- Visual Studio 2022 (or Visual Studio with ASP.NET and web development workload)
- .NET Framework 4.8 Developer Pack
- SQL Server LocalDB (usually installed with Visual Studio)
## Run
1. Extract the ZIP.
2. Open `Web_BE_25dh230009.sln` in Visual Studio.
3. Allow NuGet package restore.
4. Build the solution.
5. Press F5 / IIS Express.
6. Browse to `/Admin/Products`.
Demo admin login:
- Username: `admin`
- Password: `Admin@123`
This is a classroom/demo authentication flow. For production, use ASP.NET Identity and hashed passwords; do not use the demo credentials in a real deployment.

## Database
The connection string uses `(LocalDB)\\MSSQLLocalDB` and database name `Web_BE_25dh230009`. EF Code First creates the database and seed data on first access.

## Notes
- This project uses classic ASP.NET MVC 5 on .NET Framework, not ASP.NET Core.
- NuGet packages are restored by Visual Studio; the ZIP does not bundle package binaries.
- The sample admin authentication is deliberately simple to make the project self-contained for a class exercise.
