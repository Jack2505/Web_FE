using System;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using PagedList;
using Web_BE_25dh230009.Models;
using Web_BE_25dh230009.Models.ViewModels;

namespace Web_BE_25dh230009.Areas.Admin.Controllers
{
    [Authorize]
    public class ProductsController : Controller
    {
        private readonly StoreContext db = new StoreContext();

        public ActionResult Index(string keyword, decimal? minPrice, decimal? maxPrice, string sortOrder, int? page, int? pageSize)
        {
            int currentPage = page ?? 1;
            int size = pageSize ?? 8;
            if (currentPage < 1) currentPage = 1;
            if (size < 1 || size > 100) size = 8;

            IQueryable<Product> query = db.Products.Include(p => p.Category);

            if (!String.IsNullOrWhiteSpace(keyword))
            {
                string term = keyword.Trim();
                query = query.Where(p => p.ProductName.Contains(term) ||
                    p.ProductDescription.Contains(term) ||
                    p.Category.CategoryName.Contains(term));
            }
            if (minPrice.HasValue) query = query.Where(p => p.ProductPrice >= minPrice.Value);
            if (maxPrice.HasValue) query = query.Where(p => p.ProductPrice <= maxPrice.Value);

            switch (sortOrder)
            {
                case "name_desc": query = query.OrderByDescending(p => p.ProductName); break;
                case "price_asc": query = query.OrderBy(p => p.ProductPrice).ThenBy(p => p.ProductID); break;
                case "price_desc": query = query.OrderByDescending(p => p.ProductPrice).ThenBy(p => p.ProductID); break;
                default: sortOrder = "name_asc"; query = query.OrderBy(p => p.ProductName); break;
            }

            var vm = new ProductSearchVM
            {
                Keyword = keyword, MinPrice = minPrice, MaxPrice = maxPrice,
                SortOrder = sortOrder, PageSize = size,
                Products = query.ToPagedList(currentPage, size)
            };
            return View(vm);
        }

        public ActionResult Create()
        {
            LoadCategories();
            return View(new Product());
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Create(Product product)
        {
            if (ModelState.IsValid)
            {
                db.Products.Add(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            LoadCategories(product.CategoryID);
            return View(product);
        }

        public ActionResult Edit(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            var product = db.Products.Find(id);
            if (product == null) return HttpNotFound();
            LoadCategories(product.CategoryID);
            return View(product);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(Product product)
        {
            if (ModelState.IsValid)
            {
                db.Entry(product).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            LoadCategories(product.CategoryID);
            return View(product);
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            var product = db.Products.Include(p => p.Category).FirstOrDefault(p => p.ProductID == id);
            if (product == null) return HttpNotFound();
            return View(product);
        }

        [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var product = db.Products.Find(id);
            if (product == null) return HttpNotFound();
            db.Products.Remove(product);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        private void LoadCategories(object selected = null)
        {
            ViewBag.CategoryID = new SelectList(db.Categories.OrderBy(c => c.CategoryName), "CategoryID", "CategoryName", selected);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}
