using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web.Mvc;
using Web_BE_25dh230009.Models;

namespace Web_BE_25dh230009.Areas.Admin.Controllers
{
    [Authorize]
    public class CategoriesController : Controller
    {
        private readonly StoreContext db = new StoreContext();

        public ActionResult Index()
        {
            return View(db.Categories.Include(c => c.Products).OrderBy(c => c.CategoryName).ToList());
        }

        public ActionResult Create() { return View(new Category()); }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Create(Category category)
        {
            if (!ModelState.IsValid) return View(category);
            db.Categories.Add(category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Edit(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            var category = db.Categories.Find(id);
            if (category == null) return HttpNotFound();
            return View(category);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(Category category)
        {
            if (!ModelState.IsValid) return View(category);
            db.Entry(category).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult Delete(int? id)
        {
            if (id == null) return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            var category = db.Categories.Find(id);
            if (category == null) return HttpNotFound();
            return View(category);
        }

        [HttpPost, ActionName("Delete"), ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            var category = db.Categories.Find(id);
            if (category == null) return HttpNotFound();
            if (category.Products.Any())
            {
                ModelState.AddModelError("", "Không thể xóa danh mục đang có sản phẩm.");
                return View(category);
            }
            db.Categories.Remove(category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing) db.Dispose();
            base.Dispose(disposing);
        }
    }
}
