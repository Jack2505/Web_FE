using System.Data.Entity;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using Web_BE_25dh230009.Models;

namespace Web_BE_25dh230009
{
    public class MvcApplication : HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            Database.SetInitializer(new StoreInitializer());
            using (var db = new StoreContext()) { db.Database.Initialize(false); }
        }
    }
}
