using System.Web.Mvc;

namespace Web_BE_25dh230009.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}
