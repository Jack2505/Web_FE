using System.Collections.Generic;
using System.Data.Entity;

namespace Web_BE_25dh230009.Models
{
    public class StoreInitializer : CreateDatabaseIfNotExists<StoreContext>
    {
        protected override void Seed(StoreContext db)
        {
            var phones = new Category { CategoryName = "Điện thoại", Description = "Điện thoại và phụ kiện" };
            var laptops = new Category { CategoryName = "Laptop", Description = "Máy tính xách tay" };
            var accessories = new Category { CategoryName = "Phụ kiện", Description = "Phụ kiện công nghệ" };
            db.Categories.AddRange(new[] { phones, laptops, accessories });
            db.SaveChanges();

            db.Products.AddRange(new List<Product>
            {
                new Product { CategoryID = phones.CategoryID, ProductName = "Smartphone A", ProductDescription = "Điện thoại thông minh màn hình sắc nét", ProductPrice = 5990000, ProductImage = "" },
                new Product { CategoryID = phones.CategoryID, ProductName = "Smartphone B", ProductDescription = "Điện thoại pin dung lượng cao", ProductPrice = 7990000, ProductImage = "" },
                new Product { CategoryID = laptops.CategoryID, ProductName = "Laptop Pro 14", ProductDescription = "Laptop phục vụ học tập và công việc", ProductPrice = 22990000, ProductImage = "" },
                new Product { CategoryID = laptops.CategoryID, ProductName = "Laptop Air 13", ProductDescription = "Laptop mỏng nhẹ", ProductPrice = 18990000, ProductImage = "" },
                new Product { CategoryID = accessories.CategoryID, ProductName = "Wireless Mouse", ProductDescription = "Chuột không dây tiện dụng", ProductPrice = 350000, ProductImage = "" },
                new Product { CategoryID = accessories.CategoryID, ProductName = "USB-C Hub", ProductDescription = "Hub chuyển đổi USB-C nhiều cổng", ProductPrice = 790000, ProductImage = "" },
                new Product { CategoryID = accessories.CategoryID, ProductName = "Keyboard", ProductDescription = "Bàn phím dùng cho máy tính", ProductPrice = 650000, ProductImage = "" },
                new Product { CategoryID = phones.CategoryID, ProductName = "Smartphone C", ProductDescription = "Điện thoại camera độ phân giải cao", ProductPrice = 9990000, ProductImage = "" },
                new Product { CategoryID = laptops.CategoryID, ProductName = "Laptop Student", ProductDescription = "Laptop dành cho học sinh sinh viên", ProductPrice = 12990000, ProductImage = "" }
            });
            db.SaveChanges();
            base.Seed(db);
        }
    }
}
