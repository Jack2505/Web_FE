using System.Data.Entity;

namespace Web_BE_25dh230009.Models
{
    public class StoreContext : DbContext
    {
        public StoreContext() : base("StoreConnection") { }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Product> Products { get; set; }
    }
}
