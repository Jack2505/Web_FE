using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Web_BE_25dh230009.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }

        [Required]
        [Display(Name = "Danh mục")]
        public int CategoryID { get; set; }

        [Required, StringLength(150)]
        [Display(Name = "Tên sản phẩm")]
        public string ProductName { get; set; }

        [StringLength(2000)]
        [Display(Name = "Mô tả")]
        public string ProductDescription { get; set; }

        [Range(typeof(decimal), "0", "999999999999")]
        [Display(Name = "Giá")]
        [Column(TypeName = "money")]
        public decimal ProductPrice { get; set; }

        [StringLength(500)]
        [Display(Name = "Đường dẫn ảnh")]
        public string ProductImage { get; set; }

        public virtual Category Category { get; set; }
    }
}
