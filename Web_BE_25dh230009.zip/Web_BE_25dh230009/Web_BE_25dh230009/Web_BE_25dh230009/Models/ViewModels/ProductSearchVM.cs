using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using PagedList;

namespace Web_BE_25dh230009.Models.ViewModels
{
    public class ProductSearchVM
    {
        public string Keyword { get; set; }
        [Display(Name = "Giá từ")]
        [Range(0, 999999999)]
        public decimal? MinPrice { get; set; }
        [Display(Name = "Giá đến")]
        [Range(0, 999999999)]
        public decimal? MaxPrice { get; set; }
        public string SortOrder { get; set; }
        public int PageSize { get; set; } = 8;
        public IPagedList<Product> Products { get; set; }
    }
}
