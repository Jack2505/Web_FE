using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("Web_BE_25dh230009")]
[assembly: AssemblyDescription("ASP.NET MVC5 store admin")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Web_BE_25dh230009")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("a55c0f10-baa8-4f77-8daa-250dh230009")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
